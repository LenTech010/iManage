// SPDX-FileCopyrightText: 2023 Adam Shaw
// SPDX-License-Identifier: MIT

/*!
FullCalendar Core v6.1.5
Docs & License: https://fullcalendar.io
*/
!function(e){"use strict";FullCalendar.globalLocales.push({code:"pt",week:{dow:1,doy:4},buttonText:{prev:"Anterior",next:"Seguinte",today:"Hoje",year:"Ano",month:"Mês",week:"Semana",day:"Dia",list:"Agenda"},weekText:"Sem",allDayText:"Todo o dia",moreLinkText:"mais",noEventsText:"Não há eventos para mostrar"})}();
