// SPDX-FileCopyrightText: 2023 Adam Shaw
// SPDX-License-Identifier: MIT

/*!
FullCalendar Core v6.1.5
Docs & License: https://fullcalendar.io
*/
!function(e){"use strict";var t={code:"vi",week:{dow:1,doy:4},buttonText:{prev:"Trước",next:"Tiếp",today:"Hôm nay",year:"Năm",month:"Tháng",week:"Tuần",day:"Ngày",list:"Lịch biểu"},weekText:"Tu",allDayText:"Cả ngày",moreLinkText:e=>"+ thêm "+e,noEventsText:"Không có sự kiện để hiển thị"};FullCalendar.globalLocales.push(t)}();
