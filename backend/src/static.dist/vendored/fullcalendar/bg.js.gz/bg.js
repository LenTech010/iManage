// SPDX-FileCopyrightText: 2023 Adam Shaw
// SPDX-License-Identifier: MIT
//
/*!
FullCalendar Core v6.1.5
Docs & License: https://fullcalendar.io
(c) 2023 Adam Shaw
*/
!function(e){"use strict";var t={code:"bg",week:{dow:1,doy:7},buttonText:{prev:"назад",next:"напред",today:"днес",year:"година",month:"Месец",week:"Седмица",day:"Ден",list:"График"},allDayText:"Цял ден",moreLinkText:e=>"+още "+e,noEventsText:"Няма събития за показване"};FullCalendar.globalLocales.push(t)}();
