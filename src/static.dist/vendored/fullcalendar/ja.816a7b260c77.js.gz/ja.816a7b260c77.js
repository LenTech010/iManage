// SPDX-FileCopyrightText: 2023 Adam Shaw
// SPDX-License-Identifier: MIT

/*!
FullCalendar Core v6.1.5
Docs & License: https://fullcalendar.io
*/
!function(e){"use strict";var t={code:"ja",buttonText:{prev:"前",next:"次",today:"今日",year:"年",month:"月",week:"週",day:"日",list:"予定リスト"},weekText:"週",allDayText:"終日",moreLinkText:e=>"他 "+e+" 件",noEventsText:"表示する予定はありません"};FullCalendar.globalLocales.push(t)}();
