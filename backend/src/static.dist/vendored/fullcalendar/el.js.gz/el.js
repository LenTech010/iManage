// SPDX-FileCopyrightText: 2023 Adam Shaw
// SPDX-License-Identifier: MIT

/*!
FullCalendar Core v6.1.5
Docs & License: https://fullcalendar.io
*/
!function(e){"use strict";FullCalendar.globalLocales.push({code:"el",week:{dow:1,doy:4},buttonText:{prev:"Προηγούμενος",next:"Επόμενος",today:"Σήμερα",year:"Ετος",month:"Μήνας",week:"Εβδομάδα",day:"Ημέρα",list:"Ατζέντα"},weekText:"Εβδ",allDayText:"Ολοήμερο",moreLinkText:"περισσότερα",noEventsText:"Δεν υπάρχουν γεγονότα προς εμφάνιση"})}();
